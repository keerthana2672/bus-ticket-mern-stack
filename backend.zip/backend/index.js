const express = require("express");
const app = express();
const cors = require("cors");
const redis = require('redis');

const re= require('./utils/redis')

re();

const cron = require('node-cron');
const sch= require("./worker/index");

/*global.redisClient = redis.createClient();
global.redisClient.on('error', (err) => {
    console.log('BE Redis error: ', err);
 });


global.redisClient
   .connect()
   .then(() => {
    console.log('BE Redis connected');   })   .catch((err) => {
    console.log('BE Redis error: ', err);
  });
*/

var task = cron.schedule('* * * * *', sch);

task.start();




//const busRouter=require("./routes/busRouter")

//Middleware
app.use(express.json());
app.use(cors());

//Routes

// register and login routes
app.use("/auth", require("./routes/jwtAuth.js"));

//app.use('/dashboard', require("./routes/dashboard"));

//////////////////
app.use("/bus",require("./routes/busRouter"));
app.use("/cart",require("./routes/cartRouter"));
app.use("/pay",require("./routes/paymentRouter.js"));
app.use("/order",require("./routes/billRouter.js"));
//app.use("/dum",require("./routes/dummy.js"));



let port = process.env.port || 5000;

app.listen(port, () => {
    console.log('server currently running on port ' + port);
});