const router=require("express").Router();
const pool = require('../db');
router.get("/:uid",async (req, res) => {  
    console.log("--------------order getting")
    
    const uid=parseInt(req.params.uid);
    console.log(uid)
    try{
const billist= await pool.query(`SELECT * from orderqueue where uid=$1
`,[uid]);
 if(billist.rows.length==0)
 {
    throw( new Error("bill is unavailable"))

 }
 console.log(billist)

    //console.log(buslist.rows[0].seat)
    //res.json(buslist)
    res.json(billist)
}catch(error){
    res.status(400).json("error")
}
});

router.get("/details/:uid",async (req, res) => {  
    //const {uid,orderid}=req.body
    console.log("--------------order getting")
    
   const uid=parseInt(req.params.uid);
    console.log(uid)
    try{
const billist= await pool.query(`SELECT c.orderid, c.bid,c.seats,c.cprice,b.bfr,b.bto,b.date FROM ordertable c LEFT JOIN bus b ON c.bid = b.bid where c.orderid=$1 
`,[uid]);
 if(billist.rows.length==0)
 {
    throw( new Error("bill is unavailable"))

 }
 console.log(billist)

    //console.log(buslist.rows[0].seat)
    //res.json(buslist)
    res.json(billist)
}catch(error){
    res.status(400).json("error")
}
});


router.delete("/del",async (req, res)=>{

    const {orderid}=req.body
   try{ console.log("cancel email")
    //const user=await pool.query("SELECT * FROM usertable WHERE uid=$1",[uid]);
    const busstatus=await pool.query("SELECT * FROM ordertable where orderid=$1",[orderid])
    //console.log(busstatus)
    await pool.query("UPDATE orderqueue SET cancel=TRUE, confirm= FALSE where orderid=$1",[orderid] )
    console.log("buscancel",busstatus)
   // console.log(user.rows[0].email)
   // const mail= await pool.query("SELECT b.bfr,b.bto,c.seats,b.price FROM ordertable c LEFT JOIN bus b ON c.bid = b.bid where c.uid=$1 AND c.orderid=$2;",[uid,orderid]);
    //console.log("mailist-----------",mail)
    let bus = new Set();


    for(let k  of busstatus.rows)
    {
        bus.add(k.bid)
        console.log("bus",bus)
        let  b_id=k.bid;
        let  s_seat=k.seats;
        await pool.query("UPDATE bus SET seat[$2]=TRUE where bid=$1",[b_id,s_seat] )
        console.log("---",b_id,s_seat)
        const key_del=String(b_id)+"_"+String(s_seat)
        console.log(key_del)
        const seat_del=await global.redisClient.del(key_del)
        //const temp=seat_del(key_del)
        //console.log(temp)
        console.log("---",seat_del)
        if(seat_del==1)
        {
            console.log("deleted")
        }
        else{
            console.log("not deleted")
        }
             

    }
    res.json("finhed")
}catch(error)
{
    res.status(400).json("error")
}




} );








module.exports=router