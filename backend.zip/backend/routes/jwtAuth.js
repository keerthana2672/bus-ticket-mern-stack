const express = require('express');
const router = express.Router();
const pool = require('../db');   
const bcrypt = require('bcrypt');
const jwtGenerator = require('../utils/jwtGenerator');
//const validInfo = require('../middleware/validInfo');
//const authorization = require('../middleware/authorization');
// Registration

router.post('/register', async (req, res) => {

    try {
         // Take apart req.body (name, email, pass)
            const { name, email, password } = req.body;
            console.log({name,email,password})
           
        // Check if email already exists (if so, throw error)
            const user = await pool.query("SELECT * FROM usertable WHERE email = $1", [
                email
            ]);
            console.log("after select query")
            if (user.rows.length > 0) {
                throw( new Error("An account is already linked to that email!"));
              } 
            console.log("after checking the length of select")

              
        // Bcrypt password
              
            const saltRound = 10;
            const salt = await bcrypt.genSalt(saltRound);
            
            const bcryptPassword = await bcrypt.hash(password, salt);

        // Insert details in db
            const newUser = await pool.query("INSERT INTO usertable(name, email, password) VALUES($1, $2, $3) RETURNING *", [
                name, email, bcryptPassword
            ]);
            console.log("after inserting")
        
        // Generate JWT 
            let uid=newUser.rows[0].user_id;
            const token = jwtGenerator(newUser.rows[0].uid);
            console.log(token)
            res.json({ name, token ,uid});
        
    } catch (err) {
        res.status(400).json({error:err.message})
    }
});

// Login
router.post('/login', async (req, res) => {
    try {
        
        // req.body
        const { email, password } = req.body;
        console.log("email",email,"password",password)
        
        // error if no such user
        const user = await pool.query("SELECT * FROM usertable WHERE email = $1", [
            email
        ]);
        console.log(user)
        console.log("after query")
        if(user.rows.length === 0) {
            throw new Error("Password or Username is incorrect, please reenter.");
        }

        console.log("after length check")

        // password = db password?

        const passwordValid = await bcrypt.compare(password, user.rows[0].password);
        
        if(!passwordValid) {
            throw new Error("invaild")
        }


        // provide token
        let uid=user.rows[0].uid

        const token = jwtGenerator(user.rows[0].uid);
        const name = user.rows[0].name;
         res.json({ name, token,uid});

    } catch (err) {
        res.status(400).json({error:err.message})
    }
});

   /* router.post("/verified", authorization, (req, res) => {
        try {
            res.json(true);

        } catch (err) {
            res.status(500).send('Server Error');     
        }
    });*/

module.exports = router;