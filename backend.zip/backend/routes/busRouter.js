const router=require("express").Router();
const pool = require('../db');
//const{ searchBusControler,searchABusControler}=require("../controllers/busController");
//const searchBusController =require("../controllers/busController")


router.post("/search",async (req, res) => {  
    
    const{ bfr,bto ,date}=req.body;
    console.log({bfr,bto})
    try{
const buslist= await pool.query("SELECT * FROM bus WHERE bfr=$1 AND bto=$2 AND date=$3",[bfr ,bto,date]);
    //res.json(buslist)
    console.log(buslist)
    res.json(buslist)
}catch(error){
    res.status(400).json({error})
}

});
router.get("/search/:bid",async (req, res) => {  
    
    const bid =parseInt(req.params.bid);
    console.log(bid)
    try{
const buslist= await pool.query("SELECT * FROM bus WHERE bid=$1",[bid]);
 if(buslist.rows.length==0)
 {
    res.json("no bus")

 }
 console.log(buslist)
console.log("seat ka status")
console.log(buslist.rows[0].seat)
   
    for(let [index,iter] of buslist.rows[0].seat.entries())
    {
        console.log(index,iter)
        let buffer_key=String(bid)+"_"+String(index+1);
        const d =await global.redisClient.get(buffer_key);
        if(d!=null)
        {
            buslist.rows[0].seat[index]=false;
        }
        
    }
    //console.log(buslist.rows[0].seat)
    //res.json(buslist)
    res.json(buslist)
}catch(error){
    res.status(400).json("error")
}
});





module.exports=router

//reddis cacheing in map locations
