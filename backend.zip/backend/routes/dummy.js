const seat_del=async(key_del)=>
{
   global.redisClient.del(key_del)
   return "deleted"
}
const dum=()=>
{
  console.log("hello")
}
module.exports={
  seat_del,dum
}