const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
   // host: 'smtp.gmail.com',
   // port: 465,
   // secure: true,
    auth: {
        user: 'keerthanaravi2672@gmail.com',
        pass: 'bjcsfjtlkzxwpojm'
    },
   });
 
   const sendEmail = () => {
    const mailOptions = {
        from: 'keerthanaravi2672@gmail.com',
        to:'madhusree4124@gmail.com',
     
     subject: 'Email verification',
        text:"hello"
   };
 
   transporter.sendMail(mailOptions, function (error, info) {
     if (error) {
       console.log('Error in sending email  ' + error);
       return true;
     } else {
      console.log('Email sent: ' + info.response);
      return false;
    }
});
};
sendEmail();

//module.exports = sendEmail;