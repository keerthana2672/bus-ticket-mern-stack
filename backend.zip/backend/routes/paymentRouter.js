const router=require("express").Router();
const pool = require('../db');

router.delete("/a",async(req,res)=>{
    
        const { uid,cardno,name,cvv,pay}=req.body;
        console.log("-----------------payment--------------------",uid,cardno,name,cvv,pay)
        try {
            const c=await pool.query("SELECT * FROM card WHERE cardno=$1 AND name=$2 AND cvv=$3 AND bal>$4",[cardno,name,cvv,pay])
            console.log(c)
            //console.log(await pool.query("SELECT * FROM card "))
           //console.log(card)
        if( c.rows.length==0)
        {

        
            throw( new Error("INvalid card or invalid balance"));
            /////
        }
        const new_bal=c.rows[0].bal-pay;
        console.log("new_bal",new_bal)
       await pool.query("UPDATE card SET bal = $2 WHERE cardno=$1 ",[cardno,new_bal]); 
       //const cur_time=Date.now().toISOString();
       const now = new Date();

    const isoString = now.toISOString();

    console.log(isoString);
    let t_1=false;
            let f_1=false;
            let f_2=false;

      // console.log(cur_time)
        const or=await pool .query("INSERT INTO orderqueue (uid,ordertime,queue,confirm,cancel) VALUES ($1,$2,$3,$4,$5)",[uid,isoString,t_1,f_1,f_2])
        const od= await pool.query("SELECT * FROM orderqueue WHERE uid=$1 AND ordertime=$2",[uid,isoString])
        const order_id=od.rows[0].orderid;
        console.log(order_id)

        const orderpush= await pool.query("SELECT * FROM cart WHERE uid=$1",[uid])
        console.log(orderpush)
        console.log(orderpush.rows)
       
       for(let k  in orderpush.rows)
       {
        let t=orderpush.rows[k]  
        console.log(t)  
        let {bid:order_bid,
                uid:order_uid,
                seats:order_seats,
                cprice:order_cprice} =t;
            
            console.log(k)
            console.log(order_bid,order_uid,order_seats)
            
            
            await pool.query(" INSERT INTO ordertable (orderid,bid,uid,seats,cprice,queue,confirm,cancel) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",[order_id,order_bid,order_uid,order_seats,order_cprice,t_1,f_1,f_2])
            //await pool.query("INSERT INTO order")
        
        }
        await pool.query("DELETE FROM cart WHERE uid=$1",[uid])
        res.json(od)
    }
    catch(error){
        res.send(400).json("error")
    }


})





//node-cron


module.exports=router;
