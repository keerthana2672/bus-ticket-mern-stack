const router=require("express").Router();
const pool = require('../db');
//const redis = require("../utils/redis")
//redis.init


router.delete("/",async (req, res) => {
    console.log("----view cart------")
    const {uid}=req.body;
    console.log(uid)
    try{
        const cartlist= await pool.query("SELECT uid,c.bid,c.seats,c.cprice,b.bfr,b.bto FROM cart c LEFT JOIN bus b ON c.bid = b.bid where c.uid=$1;",[uid]);
        if(cartlist.rows.length==0)
        {
            throw new Error("empty cart");
        }

        for(let iter of cartlist.rows)
        {
        let buffer_bid=iter.bid;
        console.log(buffer_bid)
        let buffer_seats=iter.seats;
        console.log(buffer_seats)
        let buffer_key=String(buffer_bid)+"_"+String(buffer_seats)
        console.log(buffer_key)
        
        const d =await global.redisClient.get(buffer_key)
        console.log(d)
        if(d==null)
        {
           await pool.query("DELETE FROM cart WHERE uid=$1 AND bid=$2 AND seats=$3",[uid,buffer_bid,buffer_seats])  
          const db=await pool.query("SELECT uid,c.bid,c.seats,c.cprice,b.bfr,b.bto FROM cart c LEFT JOIN bus b ON c.bid = b.bid where c.uid=$1;",[uid]);
          console.log(db.rows)
        }
        
    }


    

    const newcart=await pool.query("SELECT uid,c.bid,c.seats,c.cprice,b.bfr,b.bto FROM cart c LEFT JOIN bus b ON c.bid = b.bid where c.uid=$1;",[uid])
            
            res.json(newcart)
               
         }catch(error){
            res.status(400).json("nothing in cart")
        }

 
    
});
router.put("/add",async (req,res)=>{
    console.log("----add----")

    const {uid,bid,seats}=req.body;
    console.log()
   // console.log("object",{uid,bid,seats})

try{
    console.log(String(bid)+"_"+String(seats))
   let  cac=String(bid)+"_"+String(seats)
   const ab="hello"
   console.log(ab)
   console.log(cac)

//REDDIS
    
    await global.redisClient.set(cac,'true',{EX: 1200})
    

    const connectPrice=await pool.query("SELECT * FROM bus WHERE bid=$1",[bid]);
    let cprice=connectPrice.rows[0].price;
    pool.query("INSERT INTO cart (uid,bid,seats,cprice) VALUES ($1,$2,$3,$4)",[uid,bid,seats,cprice]);
    console.log(seats);
    


   /* ////update in the bus table 
    for ( const [index,value]of seats.entries()){
        //console.log(index);
        //console.log(value);
    pool.query("UPDATE bus SET seat[$2] = FALSE WHERE bid =$1",[bid,value])*/
    //pool.query("UPDATE bus SET seat[$2] = FALSE WHERE bid =$1",[bid,seats])
    
    res.json("added");
}catch(error)
{
    res.status(400).json("cannot be added");
}

})

router.delete("/del", async(req,res)=> 
{
    console.log("start of backend delete")
    console.log(req.body)
    const {uid ,bid,seats}=req.body;
    console.log(req.body);
    try{
        const key_del=String(bid)+"_"+String(seats)
        const seat_del=await global.redisClient.del(key_del)
        if(seat_del==1)
        {
            console.log("deleted")
        }
        else{
            console.log("not deleted")
        }
    
      /* const cartlist= await pool.query("SELECT * FROM cart WHERE uid=$1 AND bid=$2 AND seats=$3",[uid,bid,seats]);
        console.log(cartlist);
        if( cartlist.rows.length==0)
            res.json ("cart and busid not found")
    
    pool.query("DELETE FROM cart WHERE uid=$1 AND bid=$2 AND seats=$3",[uid,bid,seats]).then(() => {


       /* for (let a =0;a<cartlist.rows.length;a++)
        {
             const b=cartlist.rows[a].seats;
             console.log(b)
              for ( let [ind,val] of b.entries())
              {

        //         console.log(ind, val)
                
                 pool.query("UPDATE bus SET seat[$2] = TRUE  WHERE bid =$1",[bid,val])
                console.log("update ends")
              }
        }*/
       /* pool.query("UPDATE bus SET seat[$2] = TRUE  WHERE bid =$1",[bid,seats])
                console.log("update ends")*/

        

        //console.log("delete starts");
        
        //await pool.query("DELETE FROM cart WHERE uid=$1 AND bid=$2",[uid,bid]);

        //console.log("delete ends");

        
        ///update on the bus table has to be done;;;

            res.json("successfully deleted")
    }catch (error)
    {
        res.status(500).json("server error");
    }
})
router.delete("/visit",async (req,res)=>{
    const {uid,bid}=req.body;
    console.log("--------visit start------------",uid,bid)
    try{
        //await global.redisClient.sadd(String(bid),String(uid))
        
        const letters = new Set();
        const strbid=String(bid)
        const d =await global.redisClient.get(strbid)
        console.log(d)
        if(d==null)
        {
         letters.add(uid)
        }
        else{
            const array = JSON.parse(d);
            console.log(array)
            for(const iter of array)
            {
                letters.add(iter)

            }
            letters.add(uid)
        }
        console.log(letters)
        const myArray = Array.from(letters);
        console.log("array",myArray)
        //console.log("string",String(myArray))
        const temp= JSON.stringify(myArray)
        console.log("string",temp)
        await global.redisClient.set(strbid,temp)

    
       const uids=await global.redisClient.get(strbid)
        console.log("get",uids)
        const parsedData = JSON.parse(uids)
       //const parsedData = uids
        console.log( parsedData )
       // console.log(parsedData[0])
        const ar=[]
        for ( const i of parsedData) {
            console.log(i)
          const email=await pool.query("SELECT * FROM usertable WHERE uid=$1",[i])
          console.log(email)
          console.log(email.rows[0].email)
          ar.push(email.rows[0].email)

        }
        console.log("array",ar)
    
    console.log(`Added `);
    res.json("added")
  } catch (error) {
    res.send(400).json("error")
  }

})



module.exports=router;