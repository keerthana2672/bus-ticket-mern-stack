const router=require("express").Router();
const pool = require('../db');
//const re = require("../utils/redis")
//const { createClient } =require('redis');





router.put("/add",async (req,res)=>{
    const {uid,bid}=req.body;
    console.log("start",uid,bid)
    try{
        const letters = new Set();
        const d =await global.redisClient.get(bid)
        console.log(d)
        if(d==null)
        {
         letters.add(uid)
        }
        else{
            const array = JSON.parse(d);
            for(const iter of array)
            {
                letters.add(iter)
            }
        }
        console.log(letters)
        const input = [...letters];
        console.log("array",input)
        console.log("string",String(input))

        const strbid=String(bid)
        await global.redisClient.set(strbid,String(input))


    
    console.log(`Added `);
    res.json("added")
  } catch (error) {
    res.send(400).json("error")
  }

})

module.exports=router;


