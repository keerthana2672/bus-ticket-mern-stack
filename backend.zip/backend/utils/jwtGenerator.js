const jwt = require('jsonwebtoken');
require('dotenv').config();
let jwtSecret="house1936";

function jwtGenerator(user_id) {
    const payload = {
        user: user_id,

    }

    return jwt.sign(payload,jwtSecret, { expiresIn: "1hr" });

    
}

module.exports = jwtGenerator;