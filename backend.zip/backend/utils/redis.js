const redis = require('redis');


function init() {
    global.redisClient = redis.createClient();
    global.redisClient.on('error', (err) => {
        console.log('BE Redis error: ', err);
    });


    global.redisClient
        .connect()
        .then(() => {
            console.log('BE Redis connected');
        })
        .catch((err) => {
            console.log('BE Redis error: ', err);
        });
}

module.exports =init