const amqp= require('amqplib');
const pool = require('../db');
const id=1;
//const queueName= 'Queue2';

const queue="orderprocess"
const schd=()=>{
  
  
  (async () => {
    let connection;
    try {
      const text="hello"
      connection = await amqp.connect("amqp://localhost");
      const channel = await connection.createChannel();
      let msg = await pool.query("SELECT * FROM orderqueue WHERE queue=false AND confirm=false AND cancel=false")
      console.log("-------",msg)
      await channel.assertQueue(queue, { durable: false });
      if(msg.rows.length!=0)
      {

      for(let iter in msg.rows)
      {

      msg.rows[iter].queue=true;
      await pool.query( "UPDATE orderqueue SET queue = TRUE  WHERE orderid=$1 AND uid=$2",[ msg.rows[iter].orderid,msg.rows[iter].uid])
        const m={
          orderid:msg.rows[iter].orderid,
          uid:msg.rows[iter].uid
        }
        console.log("------",m)
        channel.sendToQueue(queue, Buffer.from(JSON.stringify(m)));

      }}

      //console.log(" [x] Sent '%s'", msg);
      await channel.close();
    } catch (err) {
      console.warn(err);
    } finally {
      if (connection) await connection.close();
    }
  })();
  
  
  }

module.exports=schd;