const amqp= require('amqplib');
const {confirmemail,cancelemail}=require("./email")

const queue = "emailprocess";
//const re= require("../utils/redis")



(async() => {
  try {
    const connection = await amqp.connect("amqp://localhost");
    const channel = await connection.createChannel();

    process.once("SIGINT", async () => {
      await channel.close();
      await connection.close();
    });

    await channel.assertQueue(queue, { durable: false });
    await channel.consume(
      queue,
      (message) => {
        if (message) {
          console.log(JSON.parse(message.content.toString()));
          const k=JSON.parse(message.content.toString());
          console.log("---",k)
          if(k.status==1)
          {

            confirmemail(k.uid,k.orderid)
            
          }
          else {
            cancelemail(k.uid,k.orderid)
          }
        }

      },
      { noAck: true }
    );

    console.log(" [*] Waiting for messages. To exit press CTRL+C");
  } catch (err) {
    console.warn(err);
  }
})();