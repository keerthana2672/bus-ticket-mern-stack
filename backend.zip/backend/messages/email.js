const nodemailer = require('nodemailer');
const pool = require('../db');
const ejs = require('ejs');
const path = require('path');
//const seat_del=require("../routes/dummy")

/*const redis = require("../utils/redis")
redis()*/
const re= require("../utils/redis")

const transporter = nodemailer.createTransport({
    service: 'gmail',
   // host: 'smtp.gmail.com',
   // port: 465,
   // secure: true,
    auth: {
        user: 'keerthanaravi2672@gmail.com',
        pass: 'bjcsfjtlkzxwpojm'
    },
   });
 
   const confirmemail = async (uid,orderid) => {
    console.log("confirm email")
    const user=await pool.query("SELECT * FROM usertable WHERE uid=$1",[uid]);
    const busstatus=await pool.query("SELECT * FROM ordertable where uid=$1 AND orderid=$2",[uid,orderid])
    await pool.query("UPDATE orderqueue SET confirm=TRUE where uid=$1 AND orderid=$2",[uid,orderid] )
    for(let k  in busstatus.rows)
    {
        let  bid=busstatus.rows[k].bid;
        let  seat=busstatus.rows[k].seats;
        await pool.query("UPDATE bus SET seat[$2]=FALSE where bid=$1",[bid,seat] )


    }
    const maillist= await pool.query("SELECT b.bfr,b.bto,c.seats,b.price FROM ordertable c LEFT JOIN bus b ON c.bid = b.bid where c.uid=$1 AND c.orderid=$2;",[uid,orderid]);
   console.log(maillist.rows)
const dynamicData = {
    name: user.rows[0].name,
    orderid:orderid,
    items:maillist.rows
  };
  ejs.renderFile(path.join(__dirname, 'confirm.ejs'), dynamicData, (err, html) => {
    if (err) {
      console.error('Error rendering email template:', err);
      return;
    }
  console.log("rendered",html )
    // Create email message
    const mailOptions = {
      from:  'keerthanaravi2672@gmail.com',
      to: user.rows[0].email,
      subject: 'confirm',
      html: html // The rendered HTML content
    };
  
    // Send the email
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
      } else {
        console.log('Email sent:', info.response);
      }
    });
});
};

async function marketmailer(email,name,bid){
    console.log("---marketmail",email,name,bid)
    const busdetails= await pool.query("SELECT bfr,bto,date,price FROM bus WHERE bid=$1",[bid])
    const dynamicData = {
        name: name,
        items:busdetails.rows[0]
      };
      ejs.renderFile(path.join(__dirname, 'market.ejs'), dynamicData, (err, html) => {
        if (err) {
          console.error('Error rendering email template:', err);
          return;
        }
      console.log("rendered",html )
        // Create email message
        const mailOptions = {
          from:  'keerthanaravi2672@gmail.com',
          to: email,
          subject: 'Marketing',
          html: html // The rendered HTML content
        };
      
        // Send the email
        transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
            console.error('Error sending email:', error);
          } else {
            console.log('Email sent:', info.response);
          }
        });
    });
      }



const cancelemail = async (uid,orderid) => {
    console.log("cancel email")
    const user=await pool.query("SELECT * FROM usertable WHERE uid=$1",[uid]);
    const busstatus=await pool.query("SELECT * FROM ordertable where uid=$1 AND orderid=$2",[uid,orderid])
    //console.log(busstatus)
    await pool.query("UPDATE orderqueue SET cancel=TRUE where uid=$1 AND orderid=$2",[uid,orderid] )
    console.log("buscancel",busstatus)
    console.log(user.rows[0].email)
    re()
    const mail= await pool.query("SELECT b.bfr,b.bto,c.seats,b.price FROM ordertable c LEFT JOIN bus b ON c.bid = b.bid where c.uid=$1 AND c.orderid=$2;",[uid,orderid]);
    console.log("mailist-----------",mail)
    let bus = new Set();


    for(let k  of busstatus.rows)
    {
        bus.add(k.bid)
        console.log("bus",bus)
        let  b_id=k.bid;
        let  s_seat=k.seats;
        console.log("---",b_id,s_seat)
        const key_del=String(b_id)+"_"+String(s_seat)
        console.log(key_del)
        const seat_del=await global.redisClient.del(key_del)
        //const temp=seat_del(key_del)
        //console.log(temp)
        console.log("---",seat_del)
        if(seat_del==1)
        {
            console.log("deleted")
        }
        else{
            console.log("not deleted")
        }
             

    }
    
     
for (const iter of  bus) {
    
    const strbid=String(iter)
    console.log("bid",iter)

    const uids=await global.redisClient.get(strbid)
    console.log("get",uids)
    if(uids!=null){
    const parsedData = JSON.parse(uids)
   //const parsedrouter.get("/:uid",async (req, res) Data = uids
    console.log( parsedData )
   // console.log(parsedData[0])
    const ar=[]
    
    for ( const i of parsedData) {
        console.log(i)
      const email=await pool.query("SELECT * FROM usertable WHERE uid=$1",[i])
     
      
      marketmailer(email.rows[0].email,email.rows[0].name,iter)

    }
}
      
}



const dynamicData = {
    name: user.rows[0].name,
    orderid:orderid,
    items:mail.rows
  };
  ejs.renderFile(path.join(__dirname, 'template.ejs'), dynamicData, (err, html) => {
    if (err) {
      console.error('Error rendering email template:', err);
      return;
    }
  console.log("rendered",html )
    // Create email message
    const mailOptions = {
      from:  'keerthanaravi2672@gmail.com',
      to: user.rows[0].email,
      subject: 'cancel',
      html: html // The rendered HTML content
    };
  
    // Send the email
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
      } else {
        console.log('Email sent:', info.response);
      }
    });
});
  }


  /*ejs.renderFile(path.join(__dirname, 'template.ejs'), dynamicData, (err, html) => {
    if (err) {
      console.error('Error rendering email template:', err);
      return;
    }

    //await pool.query("DELETE FROM ordertable where uid=$1 AND orderid=$2",[uid,orderid])

    const mailOptions = {
        from: 'keerthanaravi2672@gmail.com',
        to:user.rows[0].email,
     
     subject: 'cancel',
        html:html
   };
 
   transporter.sendMail(mailOptions, function (error, info) {
     if (error) {
       console.log('Error in sending email  ' + error);
       return true;
     } else {
      console.log('Email sent: ' + info.response);
      return false;
    }*/

module.exports={
    confirmemail,cancelemail
}

