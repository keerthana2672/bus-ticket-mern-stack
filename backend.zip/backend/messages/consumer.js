const amqp= require('amqplib');

const queue = "orderprocess";
const emailqueue="emailprocess";



(async() => {
  try {
    const connection = await amqp.connect("amqp://localhost");
    const channel = await connection.createChannel();
    console.log("hello")

    process.once("SIGINT", async () => {
      await channel.close();
      await connection.close();
    });

    await channel.assertQueue(queue, { durable: false });
    await channel.consume(
      queue,
      (message) => {
        if (message) {
          console.log(JSON.parse(message.content.toString()));
            const {orderid,uid}=JSON.parse(message.content.toString());
             channel.assertQueue(emailqueue, { durable: false });
            const emailstatus={
              orderid:orderid,
              uid:uid,
              status:1
            }

            if((orderid+uid)%2)
            {
              emailstatus.status=1;

            }
            //await channel.assertQueue(emailqueue, { durable: false });
            channel.sendToQueue(emailqueue, Buffer.from(JSON.stringify(emailstatus)));
           

        }

      },
      { noAck: true }
    );

    console.log(" [*] Waiting for messages. To exit press CTRL+C");
  } catch (err) {
    console.warn(err);
  }
})();