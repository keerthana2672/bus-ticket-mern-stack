import React from 'react'
import "./style.css"
import { Link } from "react-router-dom";
import { FaShoppingCart} from 'react-icons/fa';
import{CgProfile} from 'react-icons/cg';
import {AiFillHome,AiOutlineLogout} from "react-icons/ai";
const Homeheader = () => {
  let user = JSON.parse(localStorage.getItem("user"));
  //let bus=JSON.parse(localStorage.getItem("item"));
  return (
    <div  >
         <div className='AuthHeader'>
          <div className='AuthHeader-center'>

            <h1 className='Headertext'>FLASH WAY</h1>
       </div>
       <div className='AuthHeader-center'>
        {user ? (
          <>

            <Link to='/cart' className='cart-icon'>
              <FaShoppingCart/>
            </Link>

          </>
        ) : null}
        </div>
        <div className='AuthHeader-center'>
          
              {user ? (
                <>
      
                  <Link to='/' className='cart-icon'>
                    <AiOutlineLogout/>
                  </Link>
      
                </>
              ) : null}

          
              </div>
          <div className='AuthHeader-center'>
          
          {user ? (
            <>
  
              <Link to='/bus' className='cart-icon'>
                <AiFillHome/>
              </Link>
  
            </>
          ) : null}

      
      </div>
      <div className='AuthHeader-center'>
          
          {user ? (
            <>
  
              <Link to='/order' className='cart-icon'>
                <CgProfile/>
              </Link>
  
            </>
          ) : null}

      
      </div>

        </div>
        </div>
    
     
      
      

  )
}

export default Homeheader