import React, { useState , useEffect} from "react";
import axios from "axios";
import { Link } from "react-router-dom";
//import Authheader from './Homeheader'
import "./style.css"
import Homeheader from "./Homeheader";
const Order = () => {
  const user = JSON.parse(localStorage.getItem("user"));
    const [loading,setLoading]=useState(false)
    const [orders,setOrders]=useState([])
    const [chooseorder,setChooseorder]=useState(false)
    function formatTimestamp(timestamp) {
      const date = new Date(timestamp);
      const day = date.getDate();
      const month = date.getMonth() + 1; // Months are zero-based, so add 1
      const year = date.getFullYear();
      const hour = date.getHours();
      const minute = date.getMinutes();
    
      // Pad single-digit day, month, hour, and minute with leading zeros
      const formattedDay = day < 10 ? `0${day}` : day;
      const formattedMonth = month < 10 ? `0${month}` : month;
      const formattedHour = hour < 10 ? `0${hour}` : hour;
      const formattedMinute = minute < 10 ? `0${minute}` : minute;
    
      return `${formattedDay}-${formattedMonth}-${year}        ${formattedHour}:${formattedMinute}`;
    }
    
   
    
  
 useEffect(()=>{
   async function fetc(){
    try {
      let user = JSON.parse(localStorage.getItem("user"));
      const config = {
        headers: {
          "Content-type": "application/json",
        },
      };
      console.log("-------start",user.uid)
      const d = await axios.get(
        `http://localhost:5000/order/${user.uid}`,

        config
      );
      console.log(d.data.rows)
      setOrders(d.data.rows);
      if(d.data.rows.length!==0)
      {
      setLoading(true);}
      
    } catch (error) {
      alert(error.message)
    }
    }
    fetc()
  })
  
 

  return (
    <div>
    
   <div> <Homeheader/ ></div>
    
    <div className='container'>
    <div><h1 className="Heading">YOUR ORDER</h1></div>
    <div style={{ display: 'flex', justifyContent: 'space-between', margin: '10px  100px' }}>
    <div>Uid: {user.uid}</div>
  <div>Name: {user.name}</div>
  
</div>
    <div className="Table">
    {
      loading&&(
        <table className='styled-table'>
      <thead >
        <tr>
         
          <th>ORDERID</th>
          <th>ORDERTIME</th>
          <th>STATUS</th>
          <th>DETAILS</th>
          {/*<th>DETAILS</th>*/}
         
        </tr>
      </thead>
      <tbody >
        {orders.map((item, index) => (
          <tr key={item.orderid}>
            <td>{item.orderid}</td>
            <td>{formatTimestamp(item.ordertime)}</td>
            <td>{(item.confirm)?'CONFIRMED':(item.cancel)?'CANCELED':'QUEUED'}</td>

           <td><Link to="/orderdetails"><button onClick={()=>{
              localStorage.setItem("orderdetails",JSON.stringify(item))
             

            }}>DETAILS</button></Link></td>
          </tr>
        ))}
      </tbody>
    </table>
      )
    }

    </div>
    </div>
    </div>
  );
};

export default Order;