import React, { useState} from 'react';
//import { AuthContext } from '../context/AuthContext';
import { useNavigate ,Link} from 'react-router-dom';
import axios from "axios";
import "./style.css"
const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const Navigate=useNavigate()
 // const {login,isAuth}=useContext(AuthContext)
 //const [auth,setAuth]=useState('false')

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async(e) => {
    console.log('this is submit');
    e.preventDefault();
    const config = {
      headers: {
        "Content-type": "application/json",
      },
    };
try {
  const data=await axios.post('http://localhost:5000/auth/login',{email,password},config);
  console.log("connected to db")
  localStorage.setItem("user",JSON.stringify(data.data))
  alert("Login Sucess")
  //login();
  //setAuth(true)
  console.log(data)
  Navigate('/bus')

  
} catch (error){
  alert("error")
  Navigate('/')

}
  
    
  };
  /*if(auth){
    return <Navigate to='/'  />
  }
  if(isAuth){
    return <Navigate to='/'  />
  }*/
  return (
   <>
   <div className='container'>
   <h1 className='Heading'>Login</h1>
   
    <form onSubmit={handleSubmit} className='authForm' >
      
      <label>
        Email:
        <input type="email" value={email} placeholder='Enter Email' onChange={handleEmailChange} /><br></br>
      </label>
      <label>
        Password:
        <input type="password" value={password} placeholder='Enter Password' onChange={handlePasswordChange} /><br></br>
      </label>
      <button type="submit">Login</button><br></br>
      <Link to="/register"><button>If You are not Registered</button></Link>
     
    </form>
    
    </div>
   </>
  );
};

export default Login;