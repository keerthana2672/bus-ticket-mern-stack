import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate,Link} from 'react-router-dom';
//import { useNavigate} from 'react-router-dom';
//import Header from './Header'
import "./style.css"
import Homeheader from "./Homeheader";
const Cart = () => {
    const [cart, setCart] = useState([]);
    const [loading, setLoading] = useState(false);
    const [book,setBook]=useState(false)
    const [payment,setPayment]=useState(0);
    const navigate = useNavigate();
  
    useEffect(() => {
      async function fetchCart() {
        let user = JSON.parse(localStorage.getItem("user"));
       // let token = user.token;
        const config = {
          headers: {
            "Content-type": "application/json",
            //Authorization: `Bearer ${token}`,
          },
        };
        try {
          const seats = await axios.delete(
            `http://localhost:5000/cart`,
            {data:{
              uid: user.uid}
            },
            config
          );
          console.log(seats.data.rows)
          let pay=0;
          for(let iter of seats.data.rows)
          {
            pay+=iter.cprice

          }
          setPayment(pay)
          setCart(seats.data.rows);
          if(seats.data.rows.length!==0)
          {
          setLoading(true);}
          console.log(seats.data.rows);
        } catch (error) {
          alert("cart is empty");
          navigate('/bus')
        }
      }
      fetchCart();
    }, [book]);
  
    /*async function bookSeat(id) {
      // console.log(id)
      let user = JSON.parse(localStorage.getItem("user"));
      let token = user.token;
      console.log(token)
      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
    
      try {
        const bookTicket = await axios.post(
          `https://tbs-ye6x.onrender.com/book/${id}`,{userId:user._id},
          config
        );
        if(book){
          setBook(false)
        }else{
          setBook(true)
        }
        alert("Ticket has been booked");
      } catch (error) {
        alert(error.message);
      }
    }*/
    async function cancelSeat(segment) {
      const user = JSON.parse(localStorage.getItem("user"));
      console .log("hello")
      console.log(segment.bid)
      console.log(segment.seats)
    
      //let token = user.token;
      const config = {
        headers: {
          "Content-type": "application/json"
          //Authorization: `Bearer ${token}`,
        },
      };
      try {
        console.log("start delete frontend")
        const cancelTicket = await axios.delete("http://localhost:5000/cart/del",{ data:{
            uid:user.uid,
            bid:segment.bid,
            seats:segment.seats}
        },
          config
        );
        /*if(book){
          setBook(false)
        }else{
          setBook(true)
        }*/
      
        alert("Ticket has been Delted from Cart");
      } catch (error) {
        alert(error.message);
       
        
      }
    }
  
    return (
      <div>
        <div><Homeheader/ ></div>
        <div className='container'>
        <div><h1 className="Heading">Ticket in My Cart</h1>
    
        </div>
        <div></div>
        <div>{
}</div>
        <div className='Table'>
          {loading  && (
            <table className='styled-table'>
              <thead >
                <tr>
                 
                  <th>FROM</th>
                  <th>TO</th>
                  <th>SEAT NO</th>
                  <th>PRICE</th>
                  <th>REMOVE</th>
                </tr>
              </thead>
           
              <tbody
               
              >
               {
                cart.map((item, index) => (
                  <tr key={index}>

                    <td>{item.bfr}</td>
                    <td>{item.bto}</td>
                    <td>{item.seats}</td>
                    <td>{item.cprice}</td>
                         <td>
                      <div >
                        <button
                         
                          onClick={() => {
                            cancelSeat(item);
                            window.location.reload(true)
                            setBook(true)
                          }}
                        >
                          Remove
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>

            </table>
          
          )}
        </div>{loading &&
        <Link to="/pay">
        <button onClick={()=>{
          const k={
            pay:payment
          }
       
              localStorage.setItem("payment",JSON.stringify(k))
            }}>pay<br/>
            {payment}</button></Link>}
        </div>
      </div>
    );
  };
  
  export default Cart;
  