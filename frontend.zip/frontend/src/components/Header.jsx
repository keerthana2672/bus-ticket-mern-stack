import React from 'react'
import "./style.css"
import { Link } from "react-router-dom";
const Header = () => {
  let user = JSON.parse(localStorage.getItem("user"));
  return (
    <div  >
         <div className='Header'>
            <h1 className='Headertext'>FLASH WAY</h1>
        </div>
        
      
    </div>
  )
}

export default Header