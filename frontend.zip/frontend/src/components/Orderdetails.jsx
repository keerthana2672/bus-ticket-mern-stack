import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate,Link} from 'react-router-dom';
//import { useNavigate} from 'react-router-dom';
//import Header from './Header'
import formatTimestamp from './function'
import "./style.css"
import Homeheader from "./Homeheader";
const Orderdetails = () => {
    const [details, setDetails] = useState([]);
    const [loading, setLoading] = useState(false);
    const [book,setBook]=useState(false)
    const [status,setstatus]=useState(false);
    const navigate = useNavigate();
 const or = JSON.parse(localStorage.getItem("orderdetails"))
  
    useEffect(() => {
      async function fetchdetails() {
        let user = JSON.parse(localStorage.getItem("orderdetails"));
       // let token = user.token;
        const config = {
          headers: {
            "Content-type": "application/json",
           
          },
        };
        try {
          const details = await axios.get(
            `http://localhost:5000/order/details/${user.orderid}`,

            config
          );
          console.log(details.data.rows)
          
         setstatus(user.confirm)
          setDetails(details.data.rows);
          if(details.data.rows.length!==0)
          {
          setLoading(true);}
          console.log(details.data.rows);
        } catch (error) {
          alert("some error in server");
          navigate('/order')
        }
      }
      fetchdetails();
    }, [book]);
  
    /*async function bookSeat(id) {
      // console.log(id)
      let user = JSON.parse(localStorage.getItem("user"));
      let token = user.token;
      console.log(token)
      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
    
      try {
        const bookTicket = await axios.post(
          `https://tbs-ye6x.onrender.com/book/${id}`,{userId:user._id},
          config
        );
        if(book){
          setBook(false)
        }else{
          setBook(true)
        }
        alert("Ticket has been booked");
      } catch (error) {
        alert(error.message);
      }
    }*/
    async function cancelbill(oid) {
      //const user = JSON.parse(localStorage.getItem("user"));
      console .log("hello")
      //console.log(segment.bid)
      //console.log(segment.seats)
    
      //let token = user.token;
      const config = {
        headers: {
          "Content-type": "application/json"
          //Authorization: `Bearer ${token}`,
        },
      };
      try {
        console.log("start delete frontend")
        const cancelTicket = await axios.delete("http://localhost:5000/order/del",{ data:{
            orderid:oid}
        },
          config
        );
       
      
        alert(`Your order ${oid} has been canceled`);
      } catch (error) {
        alert(error.message);
       
        
      }
    }
    
  
    return (
      <div>
        <div><Homeheader/ ></div>
        <div className='container'>
        <div><h1 className="Heading">YOUR ORDER</h1>
      {/*<div  style={{ margin: '10px' }}> 
      Orderid:{or.orderid}</div><div style={{ margin: '10px' }}>Ordertime:{formatTimestamp(or.ordertime)}</div>*/}
      <div style={{ display: 'flex', justifyContent: 'space-between', margin: '10px  100px' }}>
  <div>Orderid: {or.orderid}</div>
  <div>Ordertime: {formatTimestamp(or.ordertime)}</div>
</div>
    </div>
        <div></div>
        <div>{
}</div>
        <div className='Table'>
          {loading  && (
            <table className='styled-table'>
              <thead >
                <tr>
                 
                  <th>FROM</th>
                  <th>TO</th>
                  <th>SEAT NO</th>
                  <th>PRICE</th>
                 
                </tr>
              </thead>
           
              <tbody
               
              >
               {
                details.map((item, index) => (
                  <tr key={index}>

                    <td>{item.bfr}</td>
                    <td>{item.bto}</td>
                    <td>{item.seats}</td>
                    <td>{item.cprice}</td>
                         
                  </tr>
                ))}
              </tbody>

            </table>
          
          )}
        </div>{loading && status&&
    
        <button onClick={()=>{
          cancelbill(or.orderid)
          
       
            }}>CANCEL
            </button>}
        </div>
      </div>
    );

}
  export default Orderdetails;
  