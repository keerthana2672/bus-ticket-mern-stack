import React, { useEffect, useState } from "react";
import axios from "axios";
//import Header from './Header'
import Homeheader from './Homeheader'
import "./style.css"
import { Navigate, Link } from "react-router-dom";
//import Homeheader from "./Homeheader";
const Seat = () => {
  const [seatsofbus, setSeatsofBus] = useState([]);
  const [chooseSeat, setChooseSeat] = useState('');
  async function fetchSeats() {
    let user = JSON.parse(localStorage.getItem("item"));
    const config = {
      headers: {
        "Content-type": "application/json",
      },
    };
    try {
      console.log(user.bid)
      console.log("before search the bus with id")
      const seats = await axios.get(
        `http://localhost:5000/bus/search/${user.bid}`,
        config
      );
      console.log(seats)
      let ob = seats.data.rows[0].seat;
      console.log("the object seats config",ob)
      let arr = [];
      console.log("start of the loop")
      for (let x in ob) {
        let object = {};
        object["number"]=parseInt(x);
        object[`${x}`] = ob[x];
        console.log(object)
        arr.push(object);
      }
      console.log('lmao', arr)
      setSeatsofBus(arr);
      return arr;
    } catch (error) {
      alert(error.message);
    }
  }


  useEffect(() => {

    fetchSeats();
  }, [chooseSeat]);





  async function addToCart(sno) {
    let user = JSON.parse(localStorage.getItem("user"));
    console.log(user)
    let bus = JSON.parse(localStorage.getItem("item"));
    console.log(bus)
    //let token = user.token;
    const config = {
      headers: {
        "Content-type": "application/json",
        //Authorization: `Bearer ${token}`,
      },
    };
        console.log("befor post for addcart")
    try {
       const cart=await axios.put("http://localhost:5000/cart/add",{
       uid:user.uid,
       bid:bus.bid,
       seats:sno
       },config)

       console.log("after",cart)
      // console.log({ userId: user._id, busId: bus._id, seatNo: sno });
      //alert("ticket is  added to cart");
    } catch (error) {
      alert(error.message);
    }
  }





  return (
    <div>
      <div><Homeheader/></div>
      <div>
        <h1 className="Heading">Seat Available</h1>
        
      </div>
      <div className='seatcontainer'>
      <div className='seatarrangement'>
        {
        seatsofbus.map((element, index) => {
          return (
          
            <div key={index + 1}>
             {/* <button className="seatNo">seat No :{index + 1}</button>*/}
             
              
             
              <button
                type="button" className='seat' style={
                  {backgroundColor: !element[`${index}`] ? "rgb(255, 0, 0)" : "rgb(91, 16, 182)"
                } }
                onClick={(e) => {
                  console.log('hahahaha' , element.number)
                  // setChooseSeat(element.number); //fetch
                  fetchSeats().then(async (res) => {
                    // if(element[`${index}`]) { 
                    setChooseSeat(element.number)
                      console.log('element index', res[index][index]);
                      // console
                      // if(element[`${index}`] 
                      if(element[`${index}`] == res[index][index])
                      // && 
                      // ( seatsofbus[index].index))
                      {
                        
                      await addToCart(res[index].number + 1);
                     
                    }
                      else {
                        alert("choose an another seat it is already booked")
                      }
                  })


                }}
              >{index + 1}
                {/*{!element[`${index }`] ? (
                  <p style={{ background: "red", color: "white" }}>Booked</p>
                ) : (
                  "Availabe"
                )}*/}
              </button>
             
            </div>
          );
        })}
      </div>
      </div>
    </div>
  );
};

export default Seat;
