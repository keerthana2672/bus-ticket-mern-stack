import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
//import Authheader from './Homeheader'
import "./style.css"
import Homeheader from "./Homeheader";
const Bus = () => {
  const [fromCity, setFromCity] = useState("");
  const [toCity, setToCity] = useState("");
  const[depaturedate,setdepaturedate]=useState("")
  const [loading,setLoading]=useState(false)
  const [buses,setBuses]=useState([])

 /* useEffect(()=>{
   async function fetchCity(){
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
        },
      };
      const data = await axios.post(
        "https://tbs-ye6x.onrender.com/bus/search",
        {
          from: "ranchi",
          to: "bokaro",
        },
        config
      );
      setBuses(data.data);
      setLoading(true)
    } catch (error) {
      alert(error.message)
    }
    }
    fetchCity()
  })*/
  async function checkseats(bid){
    const config = {
      headers: {
        "Content-type": "application/json",
      },
    }
    console.log("--------checkseats--------")
    const user = JSON.parse(localStorage.getItem("user"))
    try{
      console.log(user.uid)
   const ch =  await axios.get(`http://localhost:5000/bus/search/${bid}`,
      
      config
    );
    let ob = ch.data.rows[0].seat;
    console.log("---ob---",ob)
    let counter=0;
    for( let temp of ob)
    {
      if(!temp)
      {
        counter+=1
      }
    }
    console.log("counter",counter)
  
    if(counter===20)
    {
      
        const visit = await axios.delete("http://localhost:5000/cart/visit",{ data:{
            uid:user.uid,
            bid:bid}
        },
          config
        );
        console.log("inside if")
      }
      console.log("outside if")
    }
      catch(error){
        alert(error.message);
      }

    }
      
    
    
 

  
  const handleFromCityChange = (e) => {
    setFromCity(e.target.value);
  };

  const handleToCityChange = (e) => {
    setToCity(e.target.value);
  };
 const handleToDateChange = (e) => {
  setdepaturedate(e.target.value);
};

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
        },
      };
      console.log({fromCity,toCity})
      console.log("before post query")
      const data = await axios.post(
        "http://localhost:5000/bus/search",
        {
          bfr: fromCity,
          bto: toCity,
          date:depaturedate
        },
        config
      );
      console.log("after post query")
      setBuses(data.data.rows);
      console.log(data)
      setLoading(true)
    } catch (error) {}
  };

  return (
    <div>
    
   <div> <Homeheader/ ></div>

    
    <div className='container'>
      <form className="authForm" onSubmit={handleSubmit}>
      <label>
        From:
        <input type="text" value={fromCity} onChange={handleFromCityChange} /> <>  </>
      </label>
      <label>
        To:
        <input type="text" value={toCity} onChange={handleToCityChange} /><br></br>
      </label>
      <label>Date:
      <input type="date" value={toCity} onChange={handleToDateChange} /><>  </>
      </label>
      <button type="submit">Search</button>
    </form>
    <div className="Table">
    {
      loading&&(
        <table className='styled-table'>
      <thead >
        <tr>
         
          <th>FROM</th>
          <th>TO</th>
          <th>PRICE</th>
          <th>CHECK</th>
        </tr>
      </thead>
      <tbody >
        {buses.map((item, index) => (
          <tr key={item.bid}>
            <td>{item.bfr}</td>
            <td>{item.bto}</td>
            <td>{item.price}</td>

            
            <td><Link to="/seat"><button onClick={()=>{
              localStorage.setItem("item",JSON.stringify(item))
              checkseats(item.bid)

            }}>Check</button></Link></td>
          </tr>
        ))}
      </tbody>
    </table>
      )
    }

    </div>
    </div>
    </div>
  );
};

export default Bus;
