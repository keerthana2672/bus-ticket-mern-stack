


function formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    const day = date.getDate();
    const month = date.getMonth() + 1; // Months are zero-based, so add 1
    const year = date.getFullYear();
    const hour = date.getHours();
    const minute = date.getMinutes();
  
    // Pad single-digit day, month, hour, and minute with leading zeros
    const formattedDay = day < 10 ? `0${day}` : day;
    const formattedMonth = month < 10 ? `0${month}` : month;
    const formattedHour = hour < 10 ? `0${hour}` : hour;
    const formattedMinute = minute < 10 ? `0${minute}` : minute;
  
    return `${formattedDay}-${formattedMonth}-${year}        ${formattedHour}:${formattedMinute}`;
  }
  export default formatTimestamp;