
import React, { useState } from 'react';
import axios from "axios"
import { useNavigate ,Link} from 'react-router-dom';
import Header from './Header'
import "./style.css"
//import { Link, Navigate } from 'react-router-dom';
const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShowPassword] = useState(false);
  const Navigate=useNavigate()

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
   
    setPassword(e.target.value);
  };

  const toggleShowPassword = () => {
    setShowPassword(!show);
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    const config = {
      headers: {
        "Content-type": "application/json",
      },
    };
try {
    console.log({name,email,password})
  const data=await axios.post('http://localhost:5000/auth/register',{name,email,password},config);
alert("registered")
Navigate('/')
} catch (error) {
  alert(error.message)
  Navigate('/')
}
  };

  return (
   <>
    <Header/>
   <div className='container'>
    <h1 className='Heading'>Register</h1>
    <form onSubmit={handleSubmit} className='authForm'>
      <label>
        Name:
        <input type="text" value={name} placeholder='Enter Name' onChange={handleNameChange} /><br></br>
      </label>
      <label>
        Email:
        <input type="email" value={email} placeholder='Enter Email' onChange={handleEmailChange} /><br></br>
      </label>
      <label>
        Password:
        <input
          type={show ? 'text' : 'password'}
          value={password} placeholder=' *********'
          onChange={handlePasswordChange}
        />
      </label>
      <button className='show' type="button" onClick={toggleShowPassword}>
        {show ? 'Hide' : 'Show'}
      </button><br></br>
      <button type="submit">Register</button><br></br>
      <Link to="/"><button>If You are already Register</button></Link>
    </form>
    </div>
   </>
  );
};

export default Register;