import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate} from 'react-router-dom';
import Header from './Header'
import "./style.css"
const Pay = () => {
    const [cardno, setCardno] = useState("");
    const [name, setName] = useState("");
    const[cvv,setCvv]=useState("");
    const navigate = useNavigate();

    const handleCardno = (e) => {
        setCardno(e.target.value);
      };

      const handleName = (e) => {
        setName(e.target.value);
      };
      const handleCvv= (e) => {
        setCvv(e.target.value);
      };
      const handleSubmit = async(e) => {
        e.preventDefault();
        const config = {
          headers: {
            "Content-type": "application/json",
          },
        };
    try {
        let user = JSON.parse(localStorage.getItem("user"));
        let k=JSON.parse(localStorage.getItem("payment"));
        console.log({cardno,name,cvv})
        console.log("pay",k.pay)
      const dt=await axios.delete('http://localhost:5000/pay/a',{ data:{
        uid:user.uid,
        cardno:cardno,
        name:name,
        cvv:cvv,
    pay:k.pay
  }},config);
  console.log("hello after")

  //onsole.log(dt.rows[0].orderid)
  //localStorage.setItem("order",JSON.stringify(dt.rows[0].orderid))
            alert("payment was sucessful redirecting to home")
    navigate('/bus')
    } catch (error) {
      alert("invalid card try again")
      navigate('/cart')
    }
}


return (
    <>
     <Header/>
    <div className='container'>
     <h1 className='Heading'>Card Payment</h1>
     <form onSubmit={handleSubmit} className='authForm'>
       <label>
         Card Number:

         <input type="text" value={cardno} placeholder='Enter Card Number 'onChange={handleCardno} /><br></br>
       </label>
       <label>
         Name:
         <input type="text" value={name} placeholder='Enter Name 'onChange={handleName} /><br></br>
       </label>
       <label>
         Cvv:
         <input
           type= 'text'
           value={cvv}
           placeholder='Enter cvv '
           onChange={handleCvv}
         />
       </label><br></br>
     
       <button type="submit">Pay</button><br></br>
     </form>
     </div>
    </>
   );
 
}
 export default Pay ;

