import React from 'react'
import { Route ,Routes} from 'react-router-dom'
import Home from '../components/Home'
import Login from '../components/Login'
import Register from '../components/Register'
import Bus from '../components/Bus'
import Seat from '../components/Seat'
import Cart from '../components/Cart'
import Pay from '../components/Pay'
import Order from '../components/Order'
import Orderdetails from '../components/Orderdetails'
const AllRoutes = () => {
    return (
      <Routes>
          <Route path='/' element={<Home/>} > </Route>
         {/* <Route path='/login' element={<Login/>} > </Route>*/}
          <Route path='/register' element={<Register/>} > </Route>
          <Route path='/bus' element={<Bus/>} > </Route>
          <Route path='/seat' element={<Seat/>} > </Route>
          <Route path='/cart' element={<Cart/>} > </Route>
          <Route path='/pay' element={<Pay/>} > </Route>
          <Route path='/order' element={<Order/>} > </Route>
          <Route path='/orderdetails' element={<Orderdetails/>} > </Route>
        </Routes>)
}
export default AllRoutes