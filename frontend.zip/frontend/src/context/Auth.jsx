/*import React, { useState } from 'react'

const [isAuth,setIsAuth]=useState(false);
const login()=>
{
    setIsAuth(true);
}*/
